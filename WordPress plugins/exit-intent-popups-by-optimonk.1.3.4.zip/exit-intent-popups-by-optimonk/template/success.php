<?php
if ($success) {
    echo '<div class="updated"><p>' . $success . '</p></div>';
}
