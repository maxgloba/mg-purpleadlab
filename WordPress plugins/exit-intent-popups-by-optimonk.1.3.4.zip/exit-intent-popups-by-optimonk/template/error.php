<?php if (count($error)) { ?>
<div class="error"><p><?php echo join("<br>\n", $error); ?></p></div>
<?php } ?>
