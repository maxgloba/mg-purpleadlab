<?php
/**
 * Template displays the price comparison tab
 * @param string $id
 * @param string $label
 */
?>

<li class="<?php print $tab_id ?>_tab">
    <a href="#<?php print $tab_id ?>"><?php print $label ?></a>
</li>