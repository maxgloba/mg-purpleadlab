(function ($) {
	"use strict";

    jQuery(document).ready(function($){
        
        // Smooth Scroll
        var scroll = new SmoothScroll('a[href*="#"]');

    });


}(jQuery));