# wp-ipaytotal-woocommerce
Please Note API key is mandatory to complete the integration 
Steps to get the API key 

Login to Merchant dashboard by clicking on the link https://ipaytotal.solutions
Click on the API section in the left menu 
Under the API you will see generate API key , click on generate 
After generating the API key , click on save " Please note : without saving the API , it will not work " 
Paste the API key in your Wordpress iPayTotal payment plugin/ or share the API with your developer if you are going for direct API integration then click on save .
Test the gateway with the following test card details 
4242424242424242 
11/2023 1
23
Once test is successful please check the transaction in your merchant dashboard . 
reply to this email with the successful test transaction screenshot . 
We will activate your account for live transactions. 
