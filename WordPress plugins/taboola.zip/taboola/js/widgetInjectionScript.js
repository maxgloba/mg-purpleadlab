window._taboola = window._taboola || [];
_taboola.push({mode:'{{WIDGET_ID}}', container:'{{CONTAINER}}', placement:'{{PLACEMENT}}', target_type: 'mix'});