window._taboola = window._taboola || [];
_taboola.push({flush: true});