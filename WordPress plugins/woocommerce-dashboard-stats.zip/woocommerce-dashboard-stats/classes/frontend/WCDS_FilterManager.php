<?php 
public class WCSD_FilterManager
{
	public function __construct()
	{}
}
?>