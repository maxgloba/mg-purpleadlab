<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

function adminGetPromoNoticesContent() {
    return [
        'woo' => [
        ],
        'edd' => [
        ],
        'no_woo_no_edd' => [
        ],
    ];
}
