(function($)
{
    $(function(){
        $('.mwb_wocuf_pro_colorpicker').wpColorPicker();
    });
     
})(jQuery);